module.exports.run = async (bot, message, args) => {
    if(!message.member.hasPermission("MANAGE_MESSAGES")) return message.reply("sai fora pow, tem permissao pra isso ai não");
    if(!args[0]) return message.reply(" Bota a quantidade no comando patrão!!!");
    if(parseInt(args[0])>99) return message.reply("isso tudo n da n porra!");

    message.channel.bulkDelete(parseInt(args[0])+ 1).then(() =>{
        message.channel.send(`Limpei ${args[0]} mensagens`).then(msg => msg.delete(300));
    }).catch((err) => {
        return message.reply("um erro ocorreu jamanta!");
    })
}
module.exports.help = {
    name: "faxina",
    aliases: ["limpar","clear"]
}