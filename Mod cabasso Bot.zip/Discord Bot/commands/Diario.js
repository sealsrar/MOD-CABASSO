const Discord = require("discord.js");
const fs = require("fs");
const mongoose = require("mongoose");
const botconfig = require("../botconfig.json");
const cooldowns = require("../cooldowns.json");

mongoose.connect(botconfig.mongoPass, {
    userNewUrlParser : true,
    useUnifiedTopology : true ,
})

const Data = require("../models/data.js");

module.exports.run = async(bot, message, args) => {
    let timeout = 86400000;
    let reward = 1;

    let embed = new Discord.RichEmbed();
    embed.setTitle("macacagem diaria");

    Data.findOne({
        userID: message.author.id 
    }, (err,data) => {
        if(!data){
            const newData = new Data({
                name: message.author.username,
                UserId: message.author.id,
                macacadas : 0 , 
                diario: 0, 
            })
            newData.save().catch(err => console.log(err));
          if(!colldowns[message.author.id]){
              cooldowns[message.author.id] = {
                  name: bot.users.get(message.author.id).tag,
                  diario : Date.now()
              }
              fs.writeFile("./colldowns.json", JSON.stringify(colldowns), (err) => {
                  if(err) console.log(err);
              });
          } else {
              cooldowns[message.author.id].diario
          } 
        }
    })
}


module.exports.help = {
    name : "Daily",
    aliases : ["diario","uuhuuh"]
}