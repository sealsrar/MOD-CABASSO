const mongoose = require("mongoose");
const botconfig = require("../botconfig.json");

mongoose.connect(botconfig.mongoPass, {
    userNewUrlParser : true,
    useUnifiedTopology : true ,
})

const Data = require("../models/data.js");

module.exports.run = async (bot, message, args) => {
    
    Data.findOne({
        userID: message.author.id 
    }, (err,data) => {
        if(!data){
            const newData = new Data({
                name: message.author.username,
                UserId: message.author.id,
                macacadas : 0 ,
                diario : 0 , 
            })
            newData.save().catch(err => console.log(err));
            return message.channel.send("  Você não tem macacadas");
        }
        else{
            return message.channel.send(` Você fez ${data.macacadas} macacadas, boa  macaco!`)  
        }
    })
    

}

module.exports.help = {
    name : "macaco",
    aliases : ["macacadas","monkys"]
}