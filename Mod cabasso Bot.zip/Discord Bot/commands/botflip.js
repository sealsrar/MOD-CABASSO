module.exports.run = async (bot, message, args) => {
   message.reply("uuuuuuuuuooooooooo  ");
   message.channel.send("https://media.tenor.com/images/f8275fe31d37d85cc085d0f0bb79c2d5/tenor.gif");
}

module.exports.help = {
    name : "bot flip",
    aliases : ["flip","bot flip","botflip","monkey flip"]
}